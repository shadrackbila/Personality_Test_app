<?php

return [
    'DebugKit' => [
        'onlyDebug' => true,
    ],
    'Bake' => [
        'onlyCli' => true,
        'optional' => true,
    ],
    'Migrations' => [
        'onlyCli' => true,
    ],
    'PersonalityTest' => [],
];
